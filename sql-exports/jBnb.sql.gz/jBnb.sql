-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:8889
-- Généré le :  Mar 21 Février 2017 à 23:05
-- Version du serveur :  5.6.28
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `jBnb`
--

-- --------------------------------------------------------

--
-- Structure de la table `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `currency`
--

INSERT INTO `currency` (`id`, `name`) VALUES
(1, 'dollars'),
(2, 'euro'),
(3, 'rouble');

-- --------------------------------------------------------

--
-- Structure de la table `filelist`
--

CREATE TABLE `filelist` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `src` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `file_type`
--

CREATE TABLE `file_type` (
  `id` int(11) NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `foo`
--

CREATE TABLE `foo` (
  `id` int(11) NOT NULL,
  `bar` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `fos_user`
--

CREATE TABLE `fos_user` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateOfBirth` date NOT NULL,
  `devise_id` int(11) DEFAULT NULL,
  `paypal_account` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_host` tinyint(1) NOT NULL,
  `username` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `gender_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `fos_user`
--

INSERT INTO `fos_user` (`id`, `firstname`, `lastname`, `location`, `dateOfBirth`, `devise_id`, `paypal_account`, `is_host`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `confirmation_token`, `password_requested_at`, `roles`, `gender_id`) VALUES
(1, 'adrien', 'zaganelli', 'paris', '2017-02-14', 2, 'koijhuygftdt', 1, 'a', 'a', 'adrienzaganelli@gmail.com', 'adrienzaganelli@gmail.com', 0, NULL, 'zag', NULL, NULL, NULL, 'a:0:{}', 3),
(2, 'adrien', 'admin', 'france', '1996-09-21', 1, 'moneyIsSoFunny', 0, 'admin', 'admin', 'adrien.zaganelli@hetic.net', 'adrien.zaganelli@hetic.net', 1, NULL, '$2y$13$wRloKOtDrS9YWltNgYQnP.nkQXhIqEt58ptRDdo0fB20Nq.4Wakau', '2017-02-21 22:44:02', NULL, NULL, 'a:0:{}', 2),
(3, 'adri', 'zag', 'zag', '8912-12-02', 1, 'moneyIsSoFunny', 0, 'zephirz', 'zephirz', 'adr.blood@gmail.com', 'adr.blood@gmail.com', 1, NULL, '$2y$13$0HCqX3LsZDusfEGOMq6TYeS7r1yc9Myfx69XiIqQQJl9SdPE.Zd9m', '2017-02-19 19:00:29', NULL, NULL, 'a:0:{}', 2),
(4, 'hey', 'heo', 'heay', '0123-09-11', 2, 'moneyIsSoFunny', 0, 'test3', 'test3', 'ad@kok.com', 'ad@kok.com', 1, NULL, '$2y$13$tplmeB8cOxJG3EKbJaJv8e2WvsLgiLt.wesa1QsH4thPXAzumO0FW', '2017-02-21 21:49:43', NULL, NULL, 'a:0:{}', 2),
(5, 'Adirne', 'joizhefi', 'RfGEGE', '2002-12-12', 1, 'moneyIsSoFunny', 0, '&é"é&"', '&é"é&"', 'azr@223.com', 'azr@223.com', 1, NULL, '$2y$13$SwQfRFwyIBdtdpF4AvvTTeYuIU0ZPbXHNV9qt8GnR04kAnb9VgTJq', '2017-02-21 23:00:22', NULL, NULL, 'a:0:{}', 3);

-- --------------------------------------------------------

--
-- Structure de la table `gender`
--

CREATE TABLE `gender` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `gender`
--

INSERT INTO `gender` (`id`, `name`) VALUES
(1, 'homme'),
(2, 'femme'),
(3, 'autre');

-- --------------------------------------------------------

--
-- Structure de la table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `host_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `devise_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LDK` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `localisation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `surface` int(11) NOT NULL,
  `equipements` longtext COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `statut` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `rooms`
--

INSERT INTO `rooms` (`id`, `host_id`, `type_id`, `devise_id`, `title`, `LDK`, `localisation`, `price`, `surface`, `equipements`, `description`, `statut`) VALUES
(1, 3, 2, 1, 'Ma maison', '1/2/3', 'France', '29.00', 89, '{}', 'YOLOLOLO', 1);

-- --------------------------------------------------------

--
-- Structure de la table `rooms_type`
--

CREATE TABLE `rooms_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `rooms_type`
--

INSERT INTO `rooms_type` (`id`, `name`) VALUES
(1, 'Logement entier'),
(2, 'Chambre privée'),
(3, 'Chambre partagée');

-- --------------------------------------------------------

--
-- Structure de la table `views`
--

CREATE TABLE `views` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `ip_adress` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `liked_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `filelist`
--
ALTER TABLE `filelist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_26E06F7B9E2A35A8` (`file_type_id`);

--
-- Index pour la table `file_type`
--
ALTER TABLE `file_type`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `foo`
--
ALTER TABLE `foo`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `fos_user`
--
ALTER TABLE `fos_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  ADD UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`),
  ADD UNIQUE KEY `UNIQ_957A6479C05FB297` (`confirmation_token`),
  ADD KEY `IDX_957A6479708A0E0` (`gender_id`),
  ADD KEY `IDX_957A6479F4445056` (`devise_id`);

--
-- Index pour la table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7CA11A961FB8D185` (`host_id`),
  ADD KEY `IDX_7CA11A96C54C8C93` (`type_id`),
  ADD KEY `IDX_7CA11A96F4445056` (`devise_id`);

--
-- Index pour la table `rooms_type`
--
ALTER TABLE `rooms_type`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `views`
--
ALTER TABLE `views`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `filelist`
--
ALTER TABLE `filelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `file_type`
--
ALTER TABLE `file_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `foo`
--
ALTER TABLE `foo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `fos_user`
--
ALTER TABLE `fos_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `rooms_type`
--
ALTER TABLE `rooms_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `views`
--
ALTER TABLE `views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `filelist`
--
ALTER TABLE `filelist`
  ADD CONSTRAINT `FK_26E06F7B9E2A35A8` FOREIGN KEY (`file_type_id`) REFERENCES `file_type` (`id`);

--
-- Contraintes pour la table `fos_user`
--
ALTER TABLE `fos_user`
  ADD CONSTRAINT `FK_957A6479708A0E0` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`),
  ADD CONSTRAINT `FK_957A6479F4445056` FOREIGN KEY (`devise_id`) REFERENCES `currency` (`id`);

--
-- Contraintes pour la table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `FK_7CA11A961FB8D185` FOREIGN KEY (`host_id`) REFERENCES `fos_user` (`id`),
  ADD CONSTRAINT `FK_7CA11A96C54C8C93` FOREIGN KEY (`type_id`) REFERENCES `rooms_type` (`id`),
  ADD CONSTRAINT `FK_7CA11A96F4445056` FOREIGN KEY (`devise_id`) REFERENCES `currency` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
